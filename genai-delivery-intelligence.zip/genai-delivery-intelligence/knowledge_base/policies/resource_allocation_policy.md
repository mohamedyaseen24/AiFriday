---
title: Resource Allocation Policy (placeholder)
doc_type: POLICY
scope: ALL
category: RESOURCE_ALLOCATION
status: PLACEHOLDER
effective_date: 2026-01-01
version: 0.1
---
# Resource Allocation Policy

> SYNTHETIC PLACEHOLDER. This is illustrative text written for the demo. It is NOT an approved company policy. Replace with the organisation's approved document before any use.

## Allocation limits
No specialist may be allocated above 100% across all programs. Allocations above 90% require a documented capacity check.

## Moving a specialist between programs
A specialist may move between programs only after the source and receiving program owners agree the transfer date. The receiving program must confirm skill fit for the role.

## Knowledge transfer
Moves of architects or test leads require a handover period in which the outgoing owner remains reachable for agreed days.

## Approval
Any reallocation that changes a customer delivery date requires approval from the portfolio leader before execution.
