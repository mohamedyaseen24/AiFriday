# Multi-Program Delivery Intelligence Platform

**Problem statement:** multi-program delivery predictability and resource prioritisation.

> **Demo safety:** All customers, programs, people, milestones, dependencies and financial figures are fictional/synthetic. The five policy documents are synthetic placeholders, not approved company policies. Do not use this build for real customer or staffing decisions.

## What is included

- Portfolio overview, customer/programme views, dependencies, resource allocation and risk analysis.
- Deterministic what-if simulation and resource reallocation recommendations.
- AI-assisted Q&A and agent workflow with evidence/grounding checks and an approval checkpoint.
- Policy retrieval (RAG) with document parsing, metadata, injection-pattern quarantine and retrieval noise filtering.
- Approval records, role-based access, audit events, PDF reports and an Excel workbook.
- Modular React + TypeScript frontend source, reusable view components, and a prebuilt static bundle.

## Verified baseline in this package

The uploaded source snapshot is the **SQLite + standard-library HTTP server** implementation:
- SQLite is the only implemented database backend (`DATABASE_PATH`).
- The API/static server uses Python's standard-library HTTP server; FastAPI/Pydantic are not implemented in this package.
- Retrieval uses deterministic hashed n-gram embeddings with NumPy; no neural embedding model is bundled.
- There is no historical trend endpoint or trend-chart history in this package.
- LLM adapters are optional and require a real provider key for a live hosted-model test.

The engineering handoff report in `docs/ENGINEERING_HANDOFF.docx` records the verification performed on this exact package and the remaining upgrade work.

## Quick start

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

`run.py` is the single backend entry point. On a fresh install it initializes the local SQLite database and ingests the policy files automatically, then starts the API and serves the frontend. The frontend is a module-based React + TypeScript project under `frontend/src/`. The backend serves the prebuilt `frontend/app.js` bundle and the page assets. On opening the page, the frontend creates a restricted read-only guest session automatically; no password form is shown. The ZIP includes a synthetic demo database and the demo role credentials below. If you delete `data/portfolio.db` and restart, new random credentials will be generated and saved to `data/demo_credentials.local.txt`; update this README with the newly generated values if you regenerate the database.

Open `http://127.0.0.1:8000`. The app opens directly in a read-only guest workspace. Use the following accounts when testing authenticated roles through the API or a future account-login interface:

| Role | Username | Password |
|---|---|---|
| Viewer | `viewer.demo` | `7N6Hqo-5KNjtvqgw` |
| Analyst | `analyst.demo` | `ubg7fYogv98bgidJ` |
| Approver | `leader.demo` | `eHsoFCqvwlwXrXjC` |
| Admin | `admin.demo` | `Jn1pkfIIyB5isjDI` |

These credentials are synthetic and intended for local evaluation only. Never reuse them or expose this demo database publicly. The open guest session has VIEWER permissions and cannot approve, administer users, or run analyst-only actions.

### Frontend (React modules)

The frontend is organized into reusable modules:
- `src/App.tsx` — application shell and navigation.
- `src/views/` — Overview, Dependencies, Resources, Approvals and Assistant screens.
- `src/api.ts` — API client and session handling.
- `src/types.ts` and `src/charts.tsx` — shared types and chart components.
- `styles.css` — responsive UI styles.

The production bundle (`app.js`) is included, so Node.js is not required to run the packaged app. To change the frontend and rebuild it, install Node.js 18+ and run:

```bash
cd frontend
npm install
npm run typecheck
npm run build
```

`index.html` opens the app directly in a read-only guest session. Password-based login is not displayed in the UI. The demo accounts below remain available for authenticated API access and role-specific testing.

## Useful commands

Run from `backend/`:
```bash
python -m app.cli init-db       # reset/seed local demo database and generate credentials
python -m app.cli ingest-kb     # index the five policy placeholder files
python -m app.cli reconcile    # compare seeded figures with source baseline
python -m app.cli reports      # generate two PDFs and one XLSX workbook
python -m app.cli sensitivity # evaluate ranking stability under weight perturbations
python -m unittest discover -s tests -t .
```

## Roles and safety

| Role | Permissions |
|---|---|
| VIEWER | Read dashboard, dependencies, scope, approvals and policies |
| ANALYST | Viewer + simulations, assistant questions, agent runs and reports |
| APPROVER | Analyst + approve/reject recorded recommendations |
| ADMIN | Approver + user administration and policy re-ingestion |

AI can recommend but cannot approve or execute decisions. Approval records are audit-logged. Simulation operates on in-memory copies; it does not write back to the baseline.

## Configuration

Copy `.env.example` to `.env` only if your environment loads it; otherwise export variables in the shell. Key settings include:
- `DATABASE_PATH` — SQLite database file.
- `AS_OF_DATE` — deterministic reporting date.
- `LLM_PROVIDER`, `LLM_MODEL`, `LLM_API_KEY`, `LLM_BASE_URL` — optional provider configuration.

Never commit `.env`, API keys, demo credential files or production data.

## Known limitations / next engineering steps

1. Port SQLite to PostgreSQL with migrations and integration tests against a live PostgreSQL service.
2. Move the HTTP layer to FastAPI/Pydantic and preserve all current auth, validation, rate-limit and response contracts.
3. Replace hashed n-gram retrieval with exact-token/IDF or a properly evaluated neural embedding model; compare against a labelled policy-query set.
4. Add historical delivery outcomes before calibrating risk weights; synthetic trend data must be visibly labelled and must reconcile to the baseline.
5. Run frontend type-check with real React typings and visually test all routes in a browser.
6. Run hosted LLM tests with an approved API key and verify provider-specific request/response compatibility.
7. Replace synthetic policy placeholders with approved, versioned policy documents before operational use.

See `docs/STATUS.md` and `docs/ENGINEERING_HANDOFF.docx` for test evidence and limitations.
