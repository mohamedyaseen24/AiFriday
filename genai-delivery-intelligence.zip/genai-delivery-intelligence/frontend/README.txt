React + TypeScript frontend, organized into reusable modules under src/.

Run npm install && npm run typecheck && npm run build to rebuild app.js.
The checked-in app.js is the prebuilt browser bundle. index.html loads bootstrap.js,
which opens a read-only guest session and then loads the React application.
The Python backend serves index.html, app.js, bootstrap.js and styles.css.
