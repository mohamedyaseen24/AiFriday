import { useEffect, useState } from "react";
import { api, money, ApiError } from "../api";
import { Bars } from "../charts";
import type { ChangeRequest, Option, SimResult, Specialist } from "../types";

export default function Resources({ can }: { can: (p: string) => boolean }) {
  const [specs, setSpecs] = useState<Specialist[]>([]);
  const [changes, setChanges] = useState<ChangeRequest[]>([]);
  const [impact, setImpact] = useState("");
  const [recommendation, setRecommendation] = useState("");
  const [chosen, setChosen] = useState("SP-02");
  const [options, setOptions] = useState<Option[]>([]);
  const [milestone, setMilestone] = useState("M-005");
  const [days, setDays] = useState(14);
  const [sim, setSim] = useState<SimResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { api<Specialist[]>("/api/specialists").then(setSpecs).catch(() => undefined); }, []);

  useEffect(() => {
    const params = new URLSearchParams();
    if (impact) params.set("impact", impact);
    if (recommendation) params.set("recommendation", recommendation);
    api<ChangeRequest[]>(`/api/change-requests?${params.toString()}`).then(setChanges).catch(() => undefined);
  }, [impact, recommendation]);

  const loadOptions = async (sid: string) => {
    setChosen(sid);
    try { setOptions(await api<Option[]>(`/api/reallocation/${sid}`)); setError(null); }
    catch (e) { setError(e instanceof ApiError ? e.message : "Could not load options"); }
  };

  const runSim = async () => {
    try {
      const res = await api<SimResult>("/api/simulate", {
        method: "POST", body: { scenario: { type: "DELAY_MILESTONE", params: { milestone_id: milestone, days } } },
      });
      setSim(res); setError(null);
    } catch (e) { setError(e instanceof ApiError ? e.message : "Simulation failed"); }
  };

  return (
    <>
      <div className="panel">
        <h2>Specialist capacity (% allocated, capacity 100%)</h2>
        <Bars rows={specs.map((s) => ({ label: `${s.specialist_id} ${s.role}`.slice(0, 30), value: s.total_pct,
          tone: s.total_pct > 100 ? "bad" : s.total_pct >= 90 ? "warn" : "ok" }))} max={130} unit="%" />
        <p className="muted">Select an overallocated specialist to view simulated options. Nothing is applied.</p>
        <div className="row">
          {specs.filter((s) => s.overallocated_pct > 0).map((s) => (
            <button key={s.specialist_id} className={chosen === s.specialist_id ? "primary" : "secondary"} onClick={() => loadOptions(s.specialist_id)}>
              {s.name} ({s.total_pct}%)
            </button>
          ))}
        </div>
        {options.length > 0 && (
          <table>
            <thead><tr><th>Rank</th><th>Option ({chosen})</th><th>Feasible</th><th>Contractor</th><th>Portfolio risk after</th><th>Indicative cost</th><th>Margin after</th></tr></thead>
            <tbody>
              {options.map((o) => (
                <tr key={o.rank}>
                  <td>{o.rank}{o.preferred && <span className="tag ok"> preferred</span>}</td>
                  <td>{o.description}</td><td>{o.feasible ? "Yes" : "No"}</td><td>{o.requires_contractor ? "Yes" : "No"}</td>
                  <td>{o.portfolio_risk_after_total}</td><td>{money(o.indicative_cost_impact_usd)}</td><td>{o.margin_after_pct}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="panel">
        <h2>What-if: delay a milestone (simulation only)</h2>
        <div className="row">
          <label>Milestone ID<input value={milestone} onChange={(e) => setMilestone(e.target.value)} /></label>
          <label>Delay (days)<input type="number" min={1} max={365} value={days} onChange={(e) => setDays(Number(e.target.value))} /></label>
          <button className="primary" onClick={runSim}>Run simulation</button>
        </div>
        {sim && (
          <div>
            <p className="muted">{sim.label}. Margin {sim.margin_before_pct}% to {sim.margin_after_pct}%. Indicative cost {money(sim.indicative_cost_impact_usd)}.</p>
            <ul>{sim.affected_programs.map((a) => (
              <li key={a.program_name}>{a.customer}, {a.program_name}: risk {a.risk_before} to {a.risk_after}</li>
            ))}</ul>
            <p className="muted">Assumptions: {sim.assumptions.join(" ")}</p>
          </div>
        )}
      </div>

      <div className="panel">
        <h2>Pending scope changes (recommendations, not decisions)</h2>
        <div className="row">
          <label>Impact
            <select value={impact} onChange={(e) => setImpact(e.target.value)}>
              <option value="">All</option><option>HIGH</option><option>MEDIUM</option><option>LOW</option>
            </select>
          </label>
          <label>Recommendation
            <select value={recommendation} onChange={(e) => setRecommendation(e.target.value)}>
              <option value="">All</option><option>APPROVE</option><option>DEFER</option><option>REQUEST_MORE_INFORMATION</option>
            </select>
          </label>
        </div>
        <table>
          <thead><tr><th>ID</th><th>Program</th><th>Customer</th><th>Change</th><th>Effort (days)</th><th>Schedule (days)</th><th>Est. cost</th><th>Impact</th><th>Recommendation</th></tr></thead>
          <tbody>
            {changes.map((c) => (
              <tr key={c.change_id}>
                <td>{c.change_id}</td><td>{c.program}</td><td>{c.customer}</td><td>{c.title}</td>
                <td>{c.effort_days}</td><td>{c.schedule_impact_days}</td><td>{money(c.estimated_cost_usd)}</td>
                <td>{c.impact}</td><td><span className="tag">{c.recommendation}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
        {!can("approve") && <p className="muted">Only portfolio leaders can record decisions on these items.</p>}
      </div>
      {error && <div className="error">{error}</div>}
    </>
  );
}
