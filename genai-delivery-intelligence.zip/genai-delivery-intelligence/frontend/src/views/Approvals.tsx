import { useEffect, useState } from "react";
import { api, ApiError } from "../api";
import type { Approval } from "../types";

export default function Approvals({ can }: { can: (p: string) => boolean }) {
  const [items, setItems] = useState<Approval[]>([]);
  const [status, setStatus] = useState("PENDING");
  const [message, setMessage] = useState<string | null>(null);
  const [comments, setComments] = useState<Record<number, string>>({});

  const load = () => {
    const q = status ? `?status=${status}` : "";
    api<Approval[]>(`/api/approvals${q}`).then((r) => { setItems(r); setMessage(null); })
      .catch((e: unknown) => setMessage(e instanceof ApiError ? e.message : "Could not load approvals"));
  };
  useEffect(load, [status]);

  const decide = async (id: number, decision: "APPROVED" | "REJECTED") => {
    try {
      await api(`/api/approvals/${id}/decide`, { method: "POST", body: { decision, comment: comments[id] ?? "" } });
      setMessage(`Recorded ${decision} for approval ${id}. No baseline record was changed automatically.`);
      load();
    } catch (e) {
      setMessage(e instanceof ApiError ? e.message : "Decision failed");
    }
  };

  return (
    <div className="panel">
      <h2>Approval queue</h2>
      <p className="muted">AI-generated recommendations wait here. The AI cannot approve. Only a portfolio leader or admin can record a decision.</p>
      <div className="row">
        <label>Status
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="PENDING">Pending</option><option value="APPROVED">Approved</option>
            <option value="REJECTED">Rejected</option><option value="">All</option>
          </select>
        </label>
      </div>
      {message && <div className={message.startsWith("Recorded") ? "muted" : "error"}>{message}</div>}
      <table>
        <thead><tr><th>ID</th><th>Type</th><th>Entity</th><th>Recommendation</th><th>Source</th><th>Status</th><th>Decision</th></tr></thead>
        <tbody>
          {items.map((a) => (
            <tr key={a.id}>
              <td>{a.id}</td><td>{a.kind}</td><td>{a.entity}</td><td>{a.summary}</td>
              <td className="muted">{a.source}<br />by {a.created_by}</td>
              <td><span className={`tag ${a.status === "APPROVED" ? "ok" : a.status === "REJECTED" ? "bad" : "warn"}`}>{a.status}</span></td>
              <td>
                {a.status === "PENDING" && can("approve") ? (
                  <>
                    <input placeholder="comment (optional)" value={comments[a.id] ?? ""} style={{ minWidth: 160 }}
                      onChange={(e) => setComments({ ...comments, [a.id]: e.target.value })} />
                    <div className="row" style={{ marginTop: 6 }}>
                      <button className="primary" onClick={() => decide(a.id, "APPROVED")}>Approve</button>
                      <button className="secondary" onClick={() => decide(a.id, "REJECTED")}>Reject</button>
                    </div>
                  </>
                ) : (
                  <span className="muted">{a.decided_by ? `${a.decided_by}: ${a.decision_comment ?? ""}` : "-"}</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
