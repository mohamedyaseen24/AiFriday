import { useEffect, useState } from "react";
import { api, setToken, getToken } from "./api";
import type { Me } from "./types";
import Overview from "./views/Overview";
import Dependencies from "./views/Dependencies";
import Resources from "./views/Resources";
import Approvals from "./views/Approvals";
import Assistant from "./views/Assistant";

type View = "overview" | "dependencies" | "resources" | "approvals" | "assistant";
const VIEWS: [View, string][] = [
  ["overview", "Overview"], ["dependencies", "Dependencies"], ["resources", "Resources & scope"],
  ["approvals", "Approvals"], ["assistant", "Assistant"],
];

export default function App() {
  const [me, setMe] = useState<Me | null>(null);
  const [view, setView] = useState<View>("overview");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const openWorkspace = async () => {
      try {
        if (!getToken()) {
          const session = await api<{ token: string }>("/api/auth/demo", { method: "POST" });
          setToken(session.token);
        }
        setMe(await api<Me>("/api/me"));
      } catch {
        setToken(null);
      } finally {
        setReady(true);
      }
    };
    void openWorkspace();
  }, []);

  if (!ready) return <p className="pad">Opening your workspace…</p>;
  if (!me) return <div className="panel" style={{maxWidth:520,margin:"80px auto"}}><h2>Workspace unavailable</h2><p className="muted">The demo session could not be started. Check that the backend is running and refresh this page.</p><button className="primary" onClick={() => window.location.reload()}>Retry</button></div>;

  const can = (perm: string) => me.permissions.includes(perm);

  return (
    <>
      <header>
        <h1>Delivery Intelligence</h1>
        <nav>
          {VIEWS.map(([id, label]) => (
            <button key={id} className={view === id ? "active" : ""} onClick={() => setView(id)}>{label}</button>
          ))}
        </nav>
        <span className="muted" style={{ marginLeft: "auto" }}>Open workspace · {me.role} access</span>
      </header>
      <main>
        <div className="banner">
          Synthetic example data: fictional customers, programs, people and dependencies. Figures marked
          ORIGINAL INPUT are the supplied business values. AI output is a recommendation awaiting human approval.
        </div>
        {view === "overview" && <Overview can={can} />}
        {view === "dependencies" && <Dependencies />}
        {view === "resources" && <Resources can={can} />}
        {view === "approvals" && <Approvals can={can} />}
        {view === "assistant" && <Assistant can={can} />}
      </main>
    </>
  );
}
