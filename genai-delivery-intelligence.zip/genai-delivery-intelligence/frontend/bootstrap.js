// Opens a short-lived, read-only guest session before loading the React application.
(async () => {
  const key = "di_token";
  const headers = () => ({ Authorization: `Bearer ${sessionStorage.getItem(key) || ""}` });
  let valid = false;
  if (sessionStorage.getItem(key)) {
    try {
      const check = await fetch("/api/me", { headers: headers(), cache: "no-store" });
      valid = check.ok;
    } catch (_) { /* create a fresh guest session below */ }
  }
  if (!valid) {
    sessionStorage.removeItem(key);
    const response = await fetch("/api/auth/demo", { method: "POST", cache: "no-store" });
    if (!response.ok) {
      document.getElementById("root").innerHTML = '<div class="panel" style="max-width:520px;margin:80px auto"><h2>Workspace unavailable</h2><p class="muted">Could not open the guest workspace. Start the backend and refresh this page.</p></div>';
      return;
    }
    const data = await response.json();
    sessionStorage.setItem(key, data.token);
  }
  await import("/app.js");
})().catch(() => {
  const root = document.getElementById("root");
  if (root) root.innerHTML = '<div class="panel" style="max-width:520px;margin:80px auto"><h2>Workspace unavailable</h2><p class="muted">Could not initialize the workspace. Refresh after checking the backend.</p></div>';
});
