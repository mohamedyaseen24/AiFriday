"""Single-command launcher for the Delivery Intelligence backend.

Run from this directory with: python run.py
The application services remain organized under app/ for maintainability.
"""
from pathlib import Path

from app import config
from app.database import connect, init_db
from app.genai.rag import pipeline as rag


def main():
    db_path = Path(config.DATABASE_PATH)
    if not db_path.exists():
        _, credentials = init_db()
        credentials_path = Path(config.ROOT) / "data" / "demo_credentials.local.txt"
        credentials_path.parent.mkdir(parents=True, exist_ok=True)
        with credentials_path.open("w", encoding="utf-8") as handle:
            handle.write("LOCAL DEMO ACCOUNTS — synthetic demo only; change before any shared use\n")
            for username, details in credentials.items():
                handle.write(f"{username}  role={details['role']}  password={details['password']}\n")
        conn = connect()
        try:
            rag.ingest_directory(conn, config.KNOWLEDGE_BASE_DIR)
        finally:
            conn.close()
        print("\nFirst-run demo sign-in accounts:")
        for username, details in credentials.items():
            print(f"  Username: {username:<16} Password: {details['password']}  Role: {details['role']}")
        print(f"Credentials saved locally to: {credentials_path}\n")
    elif not (Path(config.ROOT) / "data" / "demo_credentials.local.txt").exists():
        print("Existing database detected. Demo passwords are not recoverable from password hashes.")
        print("To create fresh demo sign-ins, stop the server and remove data/portfolio.db, then run again.")
    from app.server import serve_forever
    print(f"Delivery Intelligence running at http://{config.SERVER_HOST}:{config.SERVER_PORT}")
    serve_forever()


if __name__ == "__main__":
    main()
