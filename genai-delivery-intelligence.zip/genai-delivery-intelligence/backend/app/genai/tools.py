"""Schema-validated tools. Every tool returns data computed from the application snapshot or database.
Agents receive tool outputs with call IDs; nothing an LLM writes is ever treated as a tool result."""
from app.services import dependency_service, portfolio_service, report_service, resource_service
from app.services import risk_service, scope_service, simulation_service
from app.genai.rag import pipeline as rag

TYPE_MAP = {"str": str, "int": int, "float": float}


class ToolError(Exception):
    pass


class ToolRegistry:
    def __init__(self, snap, conn=None):
        self.snap = snap
        self.conn = conn
        self.tools = {}
        self.trace = []
        self._register()

    def _add(self, name, description, params, fn):
        self.tools[name] = {"description": description, "params": params, "fn": fn}

    def _register(self):
        s = self.snap
        self._add("get_portfolio_summary", "Portfolio KPIs and baseline metrics", {},
                  lambda: portfolio_service.overview(s))
        self._add("get_program_details", "Status for one program or ALL", {"program_id": "str"},
                  lambda program_id: [p for p in portfolio_service.program_status(s)
                                      if program_id in ("ALL", p["program_id"])])
        self._add("get_milestone_status", "Milestones for one program or ALL", {"program_id": "str"},
                  lambda program_id: [m for m in s["milestones"]
                                      if program_id in ("ALL", m["program_id"])])
        self._add("get_overdue_dependencies", "Overdue open dependencies with escalation priority", {},
                  lambda: dependency_service.overdue_dependencies(s))
        self._add("get_specialist_capacity", "Allocation and capacity per specialist", {},
                  lambda: resource_service.specialist_loads(s))
        self._add("get_pending_change_requests", "Pending scope changes with impact classification", {},
                  lambda: scope_service.assess(s))
        self._add("calculate_delivery_risk", "Deterministic risk score per program or ALL", {"program_id": "str"},
                  lambda program_id: [r for r in risk_service.all_program_risks(s)
                                      if program_id in ("ALL", r["program_id"])])
        self._add("simulate_resource_reallocation", "Ranked simulated options for one specialist",
                  {"specialist_id": "str"}, lambda specialist_id: simulation_service.reallocation_options(s, specialist_id))
        self._add("calculate_margin_impact", "Margin before and after approving comma-separated change IDs",
                  {"change_ids": "str"}, self._margin_impact)
        self._add("generate_recovery_plan", "Deterministic 90-day plan (targets)", {},
                  lambda: report_service.build_recovery_plan(s))
        self._add("search_policies", "Retrieve policy excerpts relevant to a query", {"query": "str"},
                  self._search_policies)

    def _margin_impact(self, change_ids):
        ids = [c.strip() for c in change_ids.split(",") if c.strip()]
        if not ids:
            raise ToolError("no change IDs supplied")
        res = simulation_service.simulate(self.snap, {"type": "APPROVE_CHANGE_REQUESTS",
                                                      "params": {"change_ids": ids}})
        return {k: res[k] for k in ("margin_before_pct", "margin_after_pct", "indicative_cost_impact_usd",
                                    "affected_programs", "label")}

    def _search_policies(self, query):
        if self.conn is None:
            return []
        return [{k: h[k] for k in ("doc_id", "title", "section", "status", "score", "text")}
                for h in rag.search(self.conn, query, k=3)]

    def call(self, name, **kwargs):
        if name not in self.tools:
            raise ToolError(f"unknown tool: {name}")
        spec = self.tools[name]
        missing, extra = set(spec["params"]) - set(kwargs), set(kwargs) - set(spec["params"])
        if missing or extra:
            raise ToolError(f"{name}: missing {sorted(missing)} or unexpected {sorted(extra)}")
        for key, typ in spec["params"].items():
            value = kwargs[key]
            if not isinstance(value, TYPE_MAP[typ]) or (typ == "int" and isinstance(value, bool)):
                raise ToolError(f"{name}: {key} must be {typ}")
        data = spec["fn"](**kwargs)
        call_id = f"TOOL-{len(self.trace) + 1:03d}"
        self.trace.append({"call_id": call_id, "tool": name, "args": kwargs})
        return {"call_id": call_id, "data": data}
