"""Strict parsing and validation of AI output. AI text is accepted only if every ID and number it uses
appears in the deterministic facts it was given, and it cannot approve anything."""
import json
import re

ID_PATTERN = re.compile(r"\b(?:PRG|DEP|SP|CR|M|CTR|ACT|POL)-(?:\d{2,3}|[0-9A-F]{6})\b")
NUM_PATTERN = re.compile(r"(?<![\w.-])\d+(?:\.\d+)?")
NARRATIVE_KEYS = {"direct_answer", "cited_ids", "recommended_actions", "approval_required"}


def parse_json_strict(text):
    if not isinstance(text, str):
        raise ValueError("model output is not text")
    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", cleaned)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        start, end = cleaned.find("{"), cleaned.rfind("}")
        if start == -1 or end <= start:
            raise ValueError("no JSON object found in model output")
        return json.loads(cleaned[start:end + 1])


def facts_allowlist(facts_text):
    return set(ID_PATTERN.findall(facts_text)), set(NUM_PATTERN.findall(facts_text))


def validate_narrative(obj, facts_text, allowed_policy_ids=()):
    """Return (ok, errors). Checks shape, approval flag, ID grounding, number grounding and policy citations."""
    errors = []
    if not isinstance(obj, dict):
        return False, ["output is not a JSON object"]
    if set(obj.keys()) != NARRATIVE_KEYS:
        errors.append(f"keys must be exactly {sorted(NARRATIVE_KEYS)}")
        return False, errors
    if obj["approval_required"] is not True:
        errors.append("approval_required must be true")
    text_fields = [obj["direct_answer"]] + list(obj["recommended_actions"])
    if not isinstance(obj["direct_answer"], str) or not 1 <= len(obj["direct_answer"]) <= 800:
        errors.append("direct_answer must be 1-800 characters")
    if not isinstance(obj["recommended_actions"], list) or not all(isinstance(a, str) for a in obj["recommended_actions"]):
        errors.append("recommended_actions must be a list of strings")
        return False, errors
    ids_allowed, nums_allowed = facts_allowlist(facts_text)
    allowed_ids = ids_allowed | set(allowed_policy_ids)
    for cid in obj["cited_ids"]:
        if cid not in allowed_ids:
            errors.append(f"cited id {cid} is not in the facts")
    for field in text_fields:
        for ident in ID_PATTERN.findall(field):
            if ident not in allowed_ids:
                errors.append(f"id {ident} is not in the facts")
        for num in NUM_PATTERN.findall(field):
            if num not in nums_allowed:
                errors.append(f"number {num} is not in the facts")
        if re.search(r"\b(approved|has been approved|executed|applied)\b", field, re.I):
            errors.append("text claims an approval or execution the system has not recorded")
    return (not errors), errors
