"""Deterministic hashed unigram + bigram embedding, L2-normalised. Stable across runs (uses sha1, not Python hash())."""
import hashlib
import re

import numpy as np

DIM = 4096
STOPWORDS = {"a", "an", "the", "of", "and", "or", "to", "in", "on", "for", "is", "are", "be", "by", "with",
             "that", "this", "it", "as", "at", "from", "if", "any", "each", "must", "should", "will", "can"}


def _tokens(text):
    words = [w for w in re.findall(r"[a-z0-9]+", text.lower()) if w not in STOPWORDS and len(w) > 1]
    stems = [w[:-1] if w.endswith("s") and len(w) > 3 else w for w in words]
    return stems + [f"{a}_{b}" for a, b in zip(stems, stems[1:])]


def embed(text):
    vec = np.zeros(DIM, dtype=np.float32)
    for tok in _tokens(text):
        digest = hashlib.sha1(tok.encode("utf-8")).digest()
        idx = int.from_bytes(digest[:4], "big") % DIM
        sign = 1.0 if digest[4] % 2 == 0 else -1.0
        vec[idx] += sign
    norm = float(np.linalg.norm(vec))
    return vec / norm if norm > 0 else vec
