"""Five specialist agents. Each only calls registry tools and emits findings that cite tool call IDs.
Findings are recommendations: they always require human approval. No agent can change the baseline."""
def _finding(agent, ftype, entity, summary, evidence, call_ids, extra=None):
    f = {"agent": agent, "type": ftype, "entity": entity, "summary": summary,
         "evidence": evidence, "tool_calls": call_ids, "approval_required": True,
         "source": "AI_AGENT_RULES"}
    f.update(extra or {})
    return f


def risk_agent(reg, state):
    call = reg.call("calculate_delivery_risk", program_id="ALL")
    out = []
    for r in call["data"]:
        if r["level"] in ("HIGH", "MEDIUM"):
            out.append(_finding("risk", "DELIVERY_RISK", r["program_id"],
                                f"{r['program_id']} risk {r['score']} ({r['level']})",
                                r["evidence"], [call["call_id"]], {"risk_level": r["level"]}))
    return out


def dependency_agent(reg, state):
    call = reg.call("get_overdue_dependencies")
    return [_finding("dependency", "DEPENDENCY_ESCALATION", d["dependency_id"],
                     f"{d['dependency_id']} {d['escalation_priority']}: {d['days_overdue']} days overdue, "
                     f"owner {d['owner']}",
                     [f"FACT: {d['dependency_id']} due {d['due_date']}, downstream {d['downstream_milestone_id']}"],
                     [call["call_id"]], {"recommended_action": d["recommended_action"]})
            for d in call["data"] if d["escalation_priority"] in ("P1 CRITICAL", "P2 HIGH")]


def resource_agent(reg, state):
    loads = reg.call("get_specialist_capacity")
    out = []
    for s in loads["data"]:
        if s["overallocated_pct"] <= 0:
            continue
        opts = reg.call("simulate_resource_reallocation", specialist_id=s["specialist_id"])
        feasible = [o for o in opts["data"] if o["feasible"]]
        if feasible:
            best = feasible[0]
            out.append(_finding("resource", "REALLOCATION_OPTION", s["specialist_id"],
                                f"{s['specialist_id']} at {s['total_pct']:g}%: {best['description']}",
                                [f"FACT: {s['specialist_id']} total allocation {s['total_pct']:g}%",
                                 f"FACT (calculated): portfolio risk total after option {best['portfolio_risk_after_total']}"],
                                [loads["call_id"], opts["call_id"]], {"steps": best["steps"],
                                                                       "requires_contractor": best["requires_contractor"]}))
        else:
            out.append(_finding("resource", "ESCALATE_CAPACITY", s["specialist_id"],
                                f"No feasible internal option for {s['specialist_id']}; leadership decision needed",
                                [f"FACT: {s['specialist_id']} total allocation {s['total_pct']:g}%"],
                                [loads["call_id"], opts["call_id"]]))
    return out


def scope_agent(reg, state):
    call = reg.call("get_pending_change_requests")
    return [_finding("scope", "SCOPE_DECISION", c["change_id"],
                     f"{c['change_id']} recommended {c['recommendation']} (impact {c['impact']})",
                     [f"FACT: {c['schedule_impact_days']:g} schedule days, effort {c['effort_days']:g} days, "
                      f"commitment conflict {c['commitment_conflict']}"],
                     [call["call_id"]], {"recommended_decision": c["recommendation"]})
            for c in call["data"] if c["recommendation"] in ("DEFER", "REQUEST_MORE_INFORMATION")]


def portfolio_agent(reg, state):
    """Coordinates other agents' findings into one portfolio priority and attaches the target-based plan."""
    risks = reg.call("calculate_delivery_risk", program_id="ALL")
    plan = reg.call("generate_recovery_plan")
    top = risks["data"][0]
    return [_finding("portfolio", "PORTFOLIO_PRIORITY", top["program_id"],
                     f"Prioritise {top['program_id']} (risk {top['score']}, {top['level']}); "
                     f"{len(plan['data'])} recovery actions proposed as TARGETS",
                     top["evidence"], [risks["call_id"], plan["call_id"]],
                     {"status_label": "AI ANALYSIS (rule-based); targets are not achieved results"})]
