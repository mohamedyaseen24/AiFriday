"""Report generation from the SAME snapshot and services used by the dashboard API.
Targets are labelled TARGET. Nothing here is an achieved result."""
import os
from datetime import timedelta
from xml.sax.saxutils import escape

from openpyxl import Workbook
from openpyxl.styles import Font
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app import config
from app.data import synthetic_portfolio as d
from app.services import dependency_service, portfolio_service, resource_service, risk_service, scope_service
from app.services import simulation_service

LABEL_LEGEND = ("Labels: ORIGINAL INPUT = supplied business figures; SYNTHETIC = fictional example records; "
                "AI ANALYSIS = deterministic rule-based analysis (no LLM used in this build); "
                "APPROVED DECISION = none recorded yet; TARGET = proposed target, not an achieved result. "
                + d.DISCLAIMER)


def _customer_name(snap, cid):
    return next(c["name"] for c in snap["customers"] if c["customer_id"] == cid)


def _best_option(snap, sid):
    opts = simulation_service.reallocation_options(snap, sid)
    return opts[0] if opts else None


def build_recovery_plan(snap):
    """Deterministic 90-day plan generated from current findings. Owners and dates are proposals."""
    as_of = snap["as_of"]
    plan = []

    def add(phase, action, owner, priority, start, target, outcome, metric, comm):
        plan.append({
            "action_id": f"ACT-{len(plan) + 1:02d}", "phase": phase, "action": action, "owner": owner,
            "priority": priority, "start_date": start.isoformat(),
            "target_completion_date": target.isoformat(), "expected_outcome": outcome,
            "success_metric": metric, "customer_communication_required": comm,
            "status_label": "TARGET (not achieved)",
        })

    for dep in dependency_service.overdue_dependencies(snap):
        p1 = dep["escalation_priority"] == "P1 CRITICAL"
        add("Days 1-30 Stabilization",
            f"Resolve or escalate {dep['dependency_id']}: {dep['description']} ({dep['provider_program']} to {dep['dependent_program']})",
            dep["owner"], dep["escalation_priority"], as_of,
            as_of + timedelta(days=14 if p1 else 21),
            f"Dependency closed; {dep['downstream_milestone_id']} forecast reconfirmed",
            "Dependency status CLOSED with date agreed by both programs",
            "Yes - inform the affected customer" if dep["escalation_priority"] in ("P1 CRITICAL", "P2 HIGH") else "No")

    for m in [m for m in snap["milestones"] if m["status"] != "ON_TIME"]:
        add("Days 1-30 Stabilization", f"Validate baseline and forecast for {m['milestone_id']} ({m['name']})",
            "Portfolio PMO lead", "HIGH", as_of, as_of + timedelta(days=30),
            "Forecast revalidated and communicated", "Forecast signed off by program owner", "Yes")

    for item in scope_service.assess(snap):
        if item["recommendation"] == "DEFER" or item["impact"] == "HIGH":
            add("Days 1-30 Stabilization",
                f"Decide on {item['change_id']} ({item['title']}): recommendation {item['recommendation']}",
                "Portfolio decision board", "HIGH", as_of, as_of + timedelta(days=21),
                "Decision recorded with rationale", "Decision logged in approval records",
                "Yes" if item["commitment_conflict"] else "No")

    overloaded = resource_service.specialist_loads(snap)
    overloaded = [s for s in overloaded if s["overallocated_pct"] > 0]
    for s in overloaded:
        best = _best_option(snap, s["specialist_id"])
        desc = best["description"] if best else "no feasible option found; escalate"
        add("Days 1-30 Stabilization",
            f"Approve reallocation for {s['name']} ({s['specialist_id']}): {desc}",
            "Resource manager with leadership approval", "HIGH", as_of, as_of + timedelta(days=30),
            "Approved option recorded", "Approval record exists before any change", "No")
        add("Days 31-60 Recovery",
            f"Execute approved reallocation for {s['specialist_id']} and confirm capacity",
            "Resource manager", "HIGH", as_of + timedelta(days=31), as_of + timedelta(days=60),
            f"{s['specialist_id']} at or below 100% total allocation",
            "Overallocated specialists = 0", "Yes if any delivery date changes")

    add("Days 31-60 Recovery", "Track approved scope changes against the baseline",
        "Delivery manager", "MEDIUM", as_of + timedelta(days=31), as_of + timedelta(days=60),
        "Scope changes visible in baseline", "100% of approved changes logged with impact", "Yes")
    add("Days 31-60 Recovery", "Monitor delivery quality, live-support coverage and indicative cost weekly",
        "Finance partner with delivery manager", "MEDIUM", as_of + timedelta(days=31),
        as_of + timedelta(days=60), "Early warning on quality and cost", "Weekly report issued on time", "No")
    add("Days 61-90 Predictability", "Run a recurring monthly portfolio review from the shared dashboard",
        "Portfolio leadership", "HIGH", as_of + timedelta(days=61), as_of + timedelta(days=90),
        "Governance cadence established", "Review held and minuted each month", "No")
    add("Days 61-90 Predictability",
        f"Reach TARGET milestone on-time rate of {config.TARGET_ON_TIME_DAY90_PCT:g}% (baseline 71%)",
        "Portfolio PMO lead", "HIGH", as_of + timedelta(days=61), as_of + timedelta(days=90),
        "Milestone reliability improves", f"On-time rate >= {config.TARGET_ON_TIME_DAY90_PCT:g}%", "Yes")
    add("Days 61-90 Predictability",
        f"Reach TARGET portfolio margin of {config.TARGET_MARGIN_DAY90_PCT:g}% (baseline 17%, plan 22%)",
        "Finance partner", "HIGH", as_of + timedelta(days=61), as_of + timedelta(days=90),
        "Margin recovery begins", f"Margin >= {config.TARGET_MARGIN_DAY90_PCT:g}%", "Yes if pricing changes")
    return plan


# ---------- PDF ----------
def _styles():
    base = getSampleStyleSheet()
    small = ParagraphStyle("small", parent=base["BodyText"], fontSize=7.5, leading=9)
    return base, small


def _pdf(path, title, blocks):
    base, small = _styles()
    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=36, rightMargin=36, topMargin=36, bottomMargin=36)
    story = [Paragraph(escape(title), base["Title"]),
             Paragraph(escape(LABEL_LEGEND), base["Italic"]), Spacer(1, 10)]
    for kind, payload in blocks:
        if kind == "h":
            story.append(Paragraph(escape(payload), base["Heading3"]))
        elif kind == "p":
            story.append(Paragraph(escape(payload), base["BodyText"]))
        elif kind == "t":
            rows = [[Paragraph(escape(str(c)), small) for c in row] for row in payload]
            t = Table(rows, repeatRows=1)
            t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                                   ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                                   ("VALIGN", (0, 0), (-1, -1), "TOP")]))
            story += [t, Spacer(1, 8)]
    doc.build(story)
    return path


def build_decision_brief_pdf(snap, path):
    ov = portfolio_service.overview(snap)
    progs = portfolio_service.program_status(snap)
    risks = risk_service.all_program_risks(snap)
    overdue = dependency_service.overdue_dependencies(snap)
    changes = scope_service.assess(snap)
    over = [s for s in resource_service.specialist_loads(snap) if s["overallocated_pct"] > 0]
    counts = {k: sum(1 for c in changes if c["recommendation"] == k)
              for k in ("APPROVE", "DEFER", "REQUEST_MORE_INFORMATION", "REJECT")}
    top2 = risks[:2]
    blocks = [
        ("h", "1. Executive summary"),
        ("p", f"AI ANALYSIS: Predictability is low. {ov['milestones_on_time']} of {ov['milestones_total']} milestones "
              f"({ov['milestone_on_time_pct']}%) are on time, {ov['overdue_dependencies']} of {ov['open_dependencies']} "
              f"open dependencies are overdue, {len(over)} key specialists are above 100%, and margin is "
              f"{ov['portfolio_margin_pct']}% against a {ov['planned_margin_pct']}% plan."),
        ("h", "2. Current portfolio performance (ORIGINAL INPUTS and SYNTHETIC records)"),
        ("t", [["Program", "Customer", "Milestones on time", "Margin %", "Overdue deps", "Risk", "Score"]] +
              [[p["name"], _customer_name(snap, p["customer_id"]),
                f"{p['milestones_on_time']}/{p['milestones']} ({p['milestone_on_time_pct']}%)",
                p["margin_pct"], p["overdue_dependencies"], p["risk_level"], p["risk_score"]] for p in progs]),
        ("h", "3. Two major delivery bottlenecks"),
        ("p", "; ".join(f"{r['program_id']} ({r['level']}, score {r['score']}): " + " | ".join(r["evidence"])
                        for r in top2)),
        ("h", "4. Customer commitment assessment"),
        ("p", "; ".join(f"{c['customer']}: max program risk {c['max_program_risk']}, milestone on-time "
                        f"{c['milestone_on_time_pct']}%, margin {c['margin_pct']}%"
                        for c in portfolio_service.customer_performance(snap))),
        ("h", "5. Resource allocation before and after (simulated, not applied)"),
    ]
    rows = [["Specialist", "Role", "Current %", "Preferred option (simulated)", "Feasible", "Contractor"]]
    for s in over:
        best = _best_option(snap, s["specialist_id"])
        rows.append([f"{s['name']} ({s['specialist_id']})", s["role"], s["total_pct"],
                     best["description"] if best else "None found",
                     "Yes" if best and best["feasible"] else "No",
                     "Yes" if best and best["requires_contractor"] else "No"])
    blocks += [("t", rows),
               ("h", "6. Dependency resolution strategy"),
               ("t", [["Dependency", "Provider to dependent", "Owner", "Days overdue", "Priority"]] +
                     [[o["dependency_id"], f"{o['provider_program']} to {o['dependent_program']}", o["owner"],
                       o["days_overdue"], o["escalation_priority"]] for o in overdue]),
               ("h", "7. Pending scope change assessment (recommendations only)"),
               ("p", f"AI ANALYSIS: {len(changes)} pending changes. Approve: {counts['APPROVE']}; defer: "
                     f"{counts['DEFER']}; request more information: {counts['REQUEST_MORE_INFORMATION']}. "
                     "REJECT decisions require an authorised person."),
               ("h", "8. Financial and margin implications"),
               ("p", f"FACT: revenue ${ov['revenue_usd']:,.0f}, cost ${ov['cost_usd']:,.0f}, margin "
                     f"{ov['portfolio_margin_pct']}% versus a {ov['planned_margin_pct']}% plan. Pending changes are "
                     f"indicatively costed at ${sum(c['estimated_cost_usd'] for c in changes):,.0f} at the blended rate "
                     "(ASSUMPTION)."),
               ("h", "9. Recommended leadership decisions (require approval)"),
               ("p", "AI ANALYSIS: Protect the digital launch first; approve or defer scope changes per section 7; "
                     "authorise the preferred reallocation for each overallocated specialist; escalate P1 dependencies "
                     "to sponsors within two business days."),
               ("h", "10. Expected outcomes (TARGETS, not achieved results)"),
               ("p", f"TARGET: on-time milestones of at least {config.TARGET_ON_TIME_DAY90_PCT:g}% and margin of at "
                     f"least {config.TARGET_MARGIN_DAY90_PCT:g}% by day 90.")]
    return _pdf(path, "Portfolio Delivery Decision Brief", blocks)


def build_recovery_plan_pdf(snap, path):
    plan = build_recovery_plan(snap)
    rows = [["ID", "Phase", "Action", "Owner", "Priority", "Start", "Target", "Success metric", "Customer comms"]]
    rows += [[a["action_id"], a["phase"], a["action"], a["owner"], a["priority"], a["start_date"],
              a["target_completion_date"], a["success_metric"], a["customer_communication_required"]] for a in plan]
    return _pdf(path, "90-Day Delivery Recovery and Customer Commitment Plan",
                [("h", "Actions (each with owner, priority, dates, outcome, metric, customer communication)"),
                 ("t", rows),
                 ("p", "All outcomes and metrics are TARGETS. Actions require approval before execution.")])


# ---------- Excel ----------
def _sheet(wb, title, headers, rows, first=False):
    ws = wb.active if first else wb.create_sheet()
    ws.title = title
    ws.append(headers)
    for c in ws[1]:
        c.font = Font(bold=True)
    for r in rows:
        ws.append(list(r))
    for col in ws.columns:
        width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
        ws.column_dimensions[col[0].column_letter].width = min(max(12, width + 2), 60)
    ws.freeze_panes = "A2"
    return ws


def build_excel(snap, path):
    wb = Workbook()
    _sheet(wb, "Read Me", ["Note"], [[LABEL_LEGEND]], first=True)
    _sheet(wb, "Original Inputs", ["Indicator", "Original value"],
           [[k.replace("_", " "), v] for k, v in d.ORIGINAL_BASELINE.items()])
    _sheet(wb, "Reconciliation", ["Check", "Expected", "Actual", "Passed"],
           [[c["check"], c["expected"], c["actual"], c["passed"]] for c in portfolio_service.reconcile(snap)])
    _sheet(wb, "Programs", ["Program", "Name", "Customer", "Milestones on time %", "Margin %",
                            "Open deps", "Overdue deps", "Risk score", "Risk level"],
           [[p["program_id"], p["name"], _customer_name(snap, p["customer_id"]), p["milestone_on_time_pct"],
             p["margin_pct"], p["open_dependencies"], p["overdue_dependencies"], p["risk_score"], p["risk_level"]]
            for p in portfolio_service.program_status(snap)])
    _sheet(wb, "Milestones", ["ID", "Program", "Name", "Planned", "Forecast", "Status"],
           [[m["milestone_id"], m["program_id"], m["name"], m["planned_date"], m["forecast_date"], m["status"]]
            for m in snap["milestones"]])
    _sheet(wb, "Dependencies", ["ID", "Provider", "Dependent", "Description", "Owner", "Due", "Status",
                                "Days overdue", "Priority", "Downstream milestone"],
           [[r["dependency_id"], r["provider_program"], r["dependent_program"], r["description"], r["owner"],
             r["due_date"], r["status"], r["days_overdue"], r["escalation_priority"], r["downstream_milestone_id"]]
            for r in dependency_service.dependency_register(snap)])
    _sheet(wb, "Change Requests", ["ID", "Program", "Customer", "Title", "Effort days", "Schedule days",
                                   "Est. cost USD", "Impact", "Recommendation"],
           [[c["change_id"], c["program"], c["customer"], c["title"], c["effort_days"],
             c["schedule_impact_days"], c["estimated_cost_usd"], c["impact"], c["recommendation"]]
            for c in scope_service.assess(snap)])
    _sheet(wb, "Resources", ["Specialist", "Name", "Role", "Key role", "Total %", "Overallocated %", "Allocations"],
           [[s["specialist_id"], s["name"], s["role"], s["is_key_role"], s["total_pct"], s["overallocated_pct"],
             "; ".join(f"{a['program_id']} {a['pct']:g}%" for a in s["allocations"])]
            for s in resource_service.specialist_loads(snap)])
    plan = build_recovery_plan(snap)
    _sheet(wb, "90-Day Plan", ["ID", "Phase", "Action", "Owner", "Priority", "Start", "Target", "Outcome",
                               "Success metric", "Customer comms", "Status"],
           [[a["action_id"], a["phase"], a["action"], a["owner"], a["priority"], a["start_date"],
             a["target_completion_date"], a["expected_outcome"], a["success_metric"],
             a["customer_communication_required"], a["status_label"]] for a in plan])
    wb.save(path)
    return path


def build_all(snap, out_dir=None):
    out_dir = out_dir or config.REPORTS_DIR
    os.makedirs(out_dir, exist_ok=True)
    return {
        "decision_brief_pdf": build_decision_brief_pdf(snap, os.path.join(out_dir, "A_portfolio_decision_brief.pdf")),
        "recovery_plan_pdf": build_recovery_plan_pdf(snap, os.path.join(out_dir, "B_90_day_recovery_plan.pdf")),
        "workbook_xlsx": build_excel(snap, os.path.join(out_dir, "portfolio_delivery_workbook.xlsx")),
    }
