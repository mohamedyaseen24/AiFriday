"""Loads a snapshot of the database and refreshes derived fields.
Simulations operate on deep copies of this snapshot and never write back."""
import copy
from datetime import date

from app import config
from app.database import connect


def _rows(conn, sql):
    return [dict(r) for r in conn.execute(sql).fetchall()]


def refresh(snap):
    """Recompute derived dependency fields from due date, status and the as-of date."""
    as_of = snap["as_of"]
    for dep in snap["dependencies"]:
        due = date.fromisoformat(dep["due_date"])
        dep["overdue"] = dep["status"] == "OPEN" and due < as_of
        dep["days_overdue"] = (as_of - due).days if dep["overdue"] else 0
    return snap


def load_snapshot(path=None):
    conn = connect(path or config.DATABASE_PATH)
    try:
        snap = {
            "as_of": config.AS_OF_DATE,
            "customers": _rows(conn, "SELECT * FROM customers ORDER BY customer_id"),
            "programs": _rows(conn, "SELECT * FROM programs ORDER BY program_id"),
            "milestones": _rows(conn, "SELECT * FROM milestones ORDER BY milestone_id"),
            "specialists": _rows(conn, "SELECT * FROM specialists ORDER BY specialist_id"),
            "allocations": _rows(conn, "SELECT * FROM resource_allocations"),
            "dependencies": _rows(conn, "SELECT * FROM dependencies ORDER BY dependency_id"),
            "change_requests": _rows(conn, "SELECT * FROM change_requests ORDER BY change_id"),
        }
    finally:
        conn.close()
    for s in snap["specialists"]:
        s["is_key_role"] = bool(s["is_key_role"])
    for c in snap["change_requests"]:
        c["dependency_impact"] = bool(c["dependency_impact"])
        c["commitment_conflict"] = bool(c["commitment_conflict"])
    return refresh(snap)


def copy_snapshot(snap):
    return copy.deepcopy(snap)
