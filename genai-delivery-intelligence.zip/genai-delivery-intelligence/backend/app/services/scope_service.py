"""Scope change classification and recommendation. Recommendations only; humans decide."""
from app import config


def classify(cr):
    sched, effort = cr["schedule_impact_days"], cr["effort_days"]
    dep, conflict = cr["dependency_impact"], cr["commitment_conflict"]
    if sched >= 10 or (dep and conflict):
        return "HIGH"
    if sched >= 5 or effort >= 20 or dep or conflict:
        return "MEDIUM"
    return "LOW"


def recommend(cr, impact):
    if impact == "HIGH":
        return "DEFER" if cr["commitment_conflict"] else "REQUEST_MORE_INFORMATION"
    if impact == "MEDIUM":
        return "REQUEST_MORE_INFORMATION" if (cr["commitment_conflict"] or cr["dependency_impact"]) else "APPROVE"
    return "REQUEST_MORE_INFORMATION" if cr["commitment_conflict"] else "APPROVE"


def assess(snap):
    programs = {p["program_id"]: p for p in snap["programs"]}
    customers = {c["customer_id"]: c["name"] for c in snap["customers"]}
    rows = []
    for cr in snap["change_requests"]:
        if cr["status"] != "PENDING":
            continue
        prog = programs[cr["program_id"]]
        impact = classify(cr)
        rows.append({
            "change_id": cr["change_id"],
            "program_id": cr["program_id"],
            "program": prog["name"],
            "customer": customers[prog["customer_id"]],
            "title": cr["title"],
            "effort_days": cr["effort_days"],
            "skills": cr["skills"],
            "schedule_impact_days": cr["schedule_impact_days"],
            "dependency_impact": cr["dependency_impact"],
            "commitment_conflict": cr["commitment_conflict"],
            "estimated_cost_usd": cr["effort_days"] * config.BLENDED_RATE_USD_PER_DAY,
            "impact": impact,
            "recommendation": recommend(cr, impact),
            "approval_required": True,
            "note": "Recommendation only. REJECT is reserved for an authorised decision-maker.",
        })
    return rows
