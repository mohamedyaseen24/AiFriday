"""Dependency register, overdue analysis and escalation priority (deterministic)."""
from app import config


def _priority(days_overdue):
    if days_overdue >= config.ESCALATE_P1_DAYS:
        return "P1 CRITICAL"
    if days_overdue >= config.ESCALATE_P2_DAYS:
        return "P2 HIGH"
    return "P3 MEDIUM"


def _action(priority):
    if priority == "P1 CRITICAL":
        return ("Escalate to the provider program sponsor within 2 business days; agree a dated "
                "recovery plan and confirm the impact on the downstream milestone.")
    if priority == "P2 HIGH":
        return "Assign a named owner with a committed revised date; review at the next portfolio meeting."
    return "Track weekly with the owner and confirm a revised date."


def dependency_register(snap):
    programs = {p["program_id"]: p for p in snap["programs"]}
    milestones = {m["milestone_id"]: m for m in snap["milestones"]}
    rows = []
    for dep in snap["dependencies"]:
        if dep["status"] != "OPEN":
            continue
        ms = milestones.get(dep["downstream_milestone_id"], {})
        priority = _priority(dep["days_overdue"]) if dep["overdue"] else "NONE"
        rows.append({
            "dependency_id": dep["dependency_id"],
            "provider_program_id": dep["provider_program_id"],
            "provider_program": programs[dep["provider_program_id"]]["name"],
            "dependent_program_id": dep["dependent_program_id"],
            "dependent_program": programs[dep["dependent_program_id"]]["name"],
            "description": dep["description"],
            "owner": dep["owner"],
            "due_date": dep["due_date"],
            "status": "OVERDUE" if dep["overdue"] else "OPEN",
            "days_overdue": dep["days_overdue"],
            "downstream_milestone_id": dep["downstream_milestone_id"],
            "downstream_milestone": ms.get("name", ""),
            "downstream_milestone_status": ms.get("status", ""),
            "downstream_forecast_date": ms.get("forecast_date", ""),
            "escalation_priority": priority,
            "recommended_action": _action(priority) if dep["overdue"] else "Monitor against due date.",
        })
    return sorted(rows, key=lambda r: (-r["days_overdue"], r["dependency_id"]))


def overdue_dependencies(snap):
    return [r for r in dependency_register(snap) if r["status"] == "OVERDUE"]
