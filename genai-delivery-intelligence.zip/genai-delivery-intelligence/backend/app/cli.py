"""Command line entry point. Run from the backend folder:  python -m app.cli <command>"""
import argparse
import json
import os
import sys

from app import config
from app.database import connect, init_db
from app.genai import orchestrator, llm
from app.genai.rag import pipeline as rag
from app.services import portfolio_service, report_service, sensitivity
from app.services.snapshot import load_snapshot


def main(argv=None):
    ap = argparse.ArgumentParser(prog="python -m app.cli")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init-db", help="Create and seed the synthetic database and demo accounts")
    sub.add_parser("ingest-kb", help="Ingest policy documents into the knowledge base")
    sub.add_parser("reconcile", help="Check synthetic data against original business inputs")
    sub.add_parser("reports", help="Generate PDF and Excel deliverables")
    sub.add_parser("sensitivity", help="Risk-weight sensitivity analysis")
    sub.add_parser("serve", help="Run the HTTP server (API and built frontend)")
    run = sub.add_parser("agent-run", help="Run the agent workflow for a question")
    run.add_argument("question")
    args = ap.parse_args(argv)

    if args.cmd == "init-db":
        path, creds = init_db()
        cred_file = os.path.join(config.ROOT, "data", "demo_credentials.local.txt")
        with open(cred_file, "w", encoding="utf-8") as fh:
            fh.write("LOCAL DEMO ACCOUNTS - change or delete before any shared use\n")
            for user, info in creds.items():
                fh.write(f"{user}  role={info['role']}  password={info['password']}\n")
        print("Database written to", path)
        print("Demo accounts written to", cred_file)
        return 0
    if args.cmd == "ingest-kb":
        conn = connect()
        print(json.dumps(rag.ingest_directory(conn, config.KNOWLEDGE_BASE_DIR), indent=2))
        return 0
    if args.cmd == "serve":
        from app.server import serve_forever
        serve_forever()
        return 0

    snap = load_snapshot()
    if args.cmd == "reconcile":
        checks = portfolio_service.reconcile(snap)
        for c in checks:
            print(f"{'PASS' if c['passed'] else 'FAIL'}  {c['check']}: expected {c['expected']}, actual {c['actual']}")
        failed = [c for c in checks if not c["passed"]]
        print(f"\n{len(checks) - len(failed)}/{len(checks)} checks passed")
        return 1 if failed else 0
    if args.cmd == "reports":
        for name, path in report_service.build_all(snap).items():
            print(f"{name}: {path}")
        return 0
    if args.cmd == "sensitivity":
        res = sensitivity.run(snap)
        print(f"top program unchanged in {res['top_program_stable_in']}/{res['total_scenarios']} scenarios; "
              f"full ranking unchanged in {res['ranking_stable_in']}/{res['total_scenarios']}")
        return 0
    if args.cmd == "agent-run":
        conn = connect()
        result = orchestrator.run_pipeline(snap, conn, args.question, "cli")
        print(json.dumps({"status": result["status"], "findings": len(result["findings"]),
                          "approval_ids": result["approval_ids"], "llm": llm.llm_status()}, indent=2))
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
